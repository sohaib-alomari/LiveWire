package sf.alomari.livewire;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import java.io.IOException;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new imageQuery().execute();


    }




    public class imageQuery extends AsyncTask<URL,Void,String>
    {


        String url="https://api.imgur.com/3/gallery/search/?q=cats";
        String result="aaa";
        @Override
        protected String doInBackground(URL... urls) {


            OkHttpClient client = new OkHttpClient();
            try {
                result = NetworkUtils.run(url);
            } catch (IOException e) {
                e.printStackTrace();
            }


            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            Log.d("Result",s);
        }
    }
}

